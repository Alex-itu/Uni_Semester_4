# scrabble
F# scrabble project


Multi-player: yes
Dictionary(Trie): yes
playing on all boards: no
parallelism: no
Respect the timeout flag: no
